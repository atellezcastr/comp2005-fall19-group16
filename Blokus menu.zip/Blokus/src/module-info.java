module blokus {
	requires java.desktop;
}