package Blokus;

import java.awt.*;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Board extends JFrame{
	private GridSquare [][] gridSquares;	
	private int x,y;
	

	
	public Board(int x, int y)
	{
		super("Blokus");
		setLayout(new GridLayout(x,y));
		
		gridSquares = new GridSquare [x][y];
		for ( int column = 0; column < x; column ++)
		{
			for ( int row = 0; row < y; row ++)
			{
				gridSquares [column][row] = new GridSquare( x,y);
				gridSquares [column][row].setSize( 20, 20);
				gridSquares [column][row].setBackground(Color.GRAY);	
				
				gridSquares [column][row].setOpaque( true);				// without this line and the next the OS' default
				gridSquares [column][row].setBorderPainted( true);		// look & feel will dominate / interfere
																		// (try commenting each out & see what happens)
	
				
				add( gridSquares [column][row]);
			}
		}
		setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE);
		
        pack();
        //setLocationRelativeTo(null);
        setResizable( true);
        setSize(900,600);
        setVisible( true);
	
		
	}
}
